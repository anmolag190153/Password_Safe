# Django Password Manager

A basic and secure password manager app build with Django, HTML, CSS, and JavaScript 

### Screenshot

![](https://i.ibb.co/prZzH5v/Django-Password-Manager.png)

### Watch tutorial on YouTube

[Build A Password Manager App from Scratch.](https://youtu.be/z87LjWauDvI)
